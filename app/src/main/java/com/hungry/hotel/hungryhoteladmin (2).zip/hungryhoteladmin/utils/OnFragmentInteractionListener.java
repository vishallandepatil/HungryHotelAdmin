package com.hungry.hotel.hungryhoteladmin.utils;

import android.net.Uri;

import androidx.fragment.app.Fragment;

public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Fragment fragment);
    }
