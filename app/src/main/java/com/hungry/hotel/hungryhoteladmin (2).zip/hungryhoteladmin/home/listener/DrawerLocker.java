package com.hungry.hotel.hungryhoteladmin.home.listener;

public interface DrawerLocker {
    void setDrawerLocked(boolean shouldLock);
}
