package com.hungry.hotel.hungryhoteladmin.restaurentmenu;


import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.hungry.hotel.hungryhoteladmin.R;
import com.hungry.hotel.hungryhoteladmin.home.HomeActivity;
import com.hungry.hotel.hungryhoteladmin.menudetails.AddUpdateMenuFragment;
import com.hungry.hotel.hungryhoteladmin.restaurentmenu.adapter.RestaurantMenuAdapter;
import com.hungry.hotel.hungryhoteladmin.restaurentmenu.api.RestaurantMenuApi;
import com.hungry.hotel.hungryhoteladmin.restaurentmenu.model.Dish;
import com.hungry.hotel.hungryhoteladmin.restaurentmenu.model.DishResponse;
import com.hungry.hotel.hungryhoteladmin.retrofit.RetrofitClientInstance;
import com.hungry.hotel.hungryhoteladmin.utils.OnFragmentInteractionListener;
import com.hungry.hotel.hungryhoteladmin.utils.Utilities;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class RestaurantMenuFragment extends Fragment {
    private OnFragmentInteractionListener mListener;
    Toolbar toolbar;
    ActionBar actionBar;
    ActionBarDrawerToggle toggle;
    DrawerLayout drawer;
    RecyclerView rvMenu;
    FloatingActionButton fabAddNewMenu;
    ArrayList<Dish> dishList;
    ProgressDialog progressDialog;
    public RestaurantMenuFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static RestaurantMenuFragment newInstance(String param1, String param2) {
        RestaurantMenuFragment fragment = new RestaurantMenuFragment();
        Bundle args = new Bundle();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View dishMenu = inflater.inflate(R.layout.fragment_restaurent_menu, container, false);
        setupToolbar();
        instantiateView(dishMenu);
        fabAddNewMenu.setOnClickListener(view -> {
            openEditMenuFragment(null);
        });


            setList();

         // List<Dish> dishList = di();

        return dishMenu;
    }

    private void instantiateView(View dishMenu) {
        rvMenu = dishMenu.findViewById(R.id.rvMenu);
        fabAddNewMenu = dishMenu.findViewById(R.id.fabAddNewMenu);
        progressDialog=new ProgressDialog(getActivity());
    }

    private void setupToolbar() {
        toolbar = ((HomeActivity) getActivity()).findViewById(R.id.toolbar);
        actionBar = ((HomeActivity) getActivity()).getSupportActionBar();
        drawer = ((HomeActivity) getActivity()).findViewById(R.id.drawer_layout);
        toggle = new ActionBarDrawerToggle(
                getActivity(), drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        toggle.setDrawerIndicatorEnabled(false);
        // Show back button
        actionBar.setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
        ((HomeActivity) getActivity()).setDrawerLocked(true);
        TextView tvToolbarTitle = toolbar.findViewById(R.id.tvToolbarTitle);
        tvToolbarTitle.setText("Menus");
        AppBarLayout.LayoutParams params =
                (AppBarLayout.LayoutParams) toolbar.getLayoutParams();
        params.setScrollFlags(AppBarLayout.LayoutParams.SCROLL_FLAG_SCROLL
                | AppBarLayout.LayoutParams.SCROLL_FLAG_ENTER_ALWAYS);
        toggle.syncState();

        /*Toolbar tbMain = getActivity().findViewById(R.id.tbMain);
        tbMain.setVisibility(View.VISIBLE);*/
        /*Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("Menus");
        toolbar.setTitleTextColor(getActivity().getResources().getColor(R.color.black));
        AutoCompleteTextView actvSearchMenu = toolbar.findViewById(R.id.actvSearchMenu);
        ImageButton ibFilter = toolbar.findViewById(R.id.ibFilter);
        ImageButton ibSearch = toolbar.findViewById(R.id.ibSearch);
        actvSearchMenu.setVisibility(View.VISIBLE);
        ibSearch.setVisibility(View.VISIBLE);
        ibFilter.setVisibility(View.VISIBLE);
        ibFilter.setOnClickListener((v) -> {
            showMenuFilter();
        });*/
    }


/*
    private List<Dish> getDishes() {
        List<Dish> dishList = new ArrayList<>();
        Dish dish = new Dish();
        dish.setDishName("Sev Bhaji");
        dish.setDishPrice(80.00);
        dish.setDishQuantity(2);
        dish.setDishStartTime("11:00 AM");
        dish.setDishEndTime("10:00 PM");
        dish.setVeg(true);
        dish.setDishImage("");
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);
        dishList.add(dish);

        return dishList;
    }
*/

    private void setRecyclerViewProperty(RecyclerView recyclerView) {
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
    }

    private void showMenuFilter() {
        String[] listItems = {"Less price ", "Max price ", "Rating", "Veg only", "Non_veg only"};
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Choose item");

        int checkedItem = 0; //this will checked the item when user open the dialog
        builder.setSingleChoiceItems(listItems, checkedItem, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getContext(), "Position: " + which + " Value: " + listItems[which], Toast.LENGTH_LONG).show();
            }
        });

        builder.setPositiveButton("Done", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

     public  void openEditMenuFragment(Dish dish) {
        AddUpdateMenuFragment fragment;
        if (dish != null) {
            fragment = AddUpdateMenuFragment.newInstance(dish);
        } else {
            fragment = new AddUpdateMenuFragment();
        }
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.clHomePageContainer, fragment);
        fragmentTransaction.addToBackStack("ADD_UPDATE_MENU");
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
        fragmentTransaction.commit();
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(this);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    void setList()
    {
        //http://hungryindia.co.in/index.php/api/Hotels/menu?api_key=kjashdkahdkhaksjdhweshkhskjdhkj&
        // TYPE=VEG&IS_SHOWN=Y&HOT_MA_ID=1
        if(Utilities.isNetworkAvailable(getActivity()))
        {
            RestaurantMenuApi restaurantMenuApi = RetrofitClientInstance.getRetrofitInstanceServer().
                    create(RestaurantMenuApi.class);

            progressDialog.setMessage("Please Wait...");
            progressDialog.setCancelable(false);
            // pbLoading.setProgressStyle(R.id.abbreviationsBar);
            progressDialog.show();
            restaurantMenuApi.getMenus(RetrofitClientInstance.API_KEY, null,null,1).
                    enqueue(new Callback<DishResponse>() {

                        @Override
                        public void onResponse(Call<DishResponse> call, Response<DishResponse> response) {

                            DishResponse hospitalResponce = response.body();
                            Log.e("onResponseckhk: ", hospitalResponce.getResult().toString());

                            dishList = new ArrayList<>();
                            dishList.clear();
                            for (int i = 1; i < hospitalResponce.getResult().size(); i++) {
                                Dish dish = new Dish(hospitalResponce.getResult().get(i).getMENU_MA_ID(),
                                        hospitalResponce.getResult().get(i).getNAME(),
                                        hospitalResponce.getResult().get(i).getAMOUNT(),
                                        hospitalResponce.getResult().get(i).getTYPE(),
                                        hospitalResponce.getResult().get(i).getQUNTITY(),
                                        hospitalResponce.getResult().get(i).getDESCRIPTION(),
                                        hospitalResponce.getResult().get(i).getCATEGORY(),
                                        hospitalResponce.getResult().get(i).getSTART_TIME(),
                                        hospitalResponce.getResult().get(i).getEND_TIME(),
                                        hospitalResponce.getResult().get(i).getIS_SHOWN(),
                                        hospitalResponce.getResult().get(i).getHOT_MA_ID(),
                                        hospitalResponce.getResult().get(i).getADDED_BY(),
                                        hospitalResponce.getResult().get(i).getPath(),
                                        hospitalResponce.getResult().get(i).getPRIORITY_ID(),
                                        hospitalResponce.getResult().get(i).getCREATED_AT(),
                                        hospitalResponce.getResult().get(i).getUPDATED_AT());
                                dishList.add(dish);

                            }

                            RestaurantMenuAdapter menuAdapter = new RestaurantMenuAdapter(getActivity(), dishList,
                                    rvMenu, this::openEditMenuFragment);
                            setRecyclerViewProperty(rvMenu);
                            rvMenu.setAdapter(menuAdapter);
                            progressDialog.dismiss();
                            Log.e("onResponse: ", dishList.toString());

                        }
                        private void openEditMenuFragment(Dish dish) {

                            AddUpdateMenuFragment fragment;
                            if (dish != null) {
                                fragment = AddUpdateMenuFragment.newInstance(dish);
                            } else {
                                fragment = new AddUpdateMenuFragment();
                            }
                            FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            fragmentTransaction.replace(R.id.clHomePageContainer, fragment);
                            fragmentTransaction.addToBackStack("ADD_UPDATE_MENU");
                            fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_OPEN);
                            fragmentTransaction.commit();
                        }

                        @Override
                        public void onFailure(Call<DishResponse> call, Throwable t) {

                            progressDialog.dismiss();

                            Toast.makeText(getActivity(), getResources().getString(R.string.something_went_wrong), Toast.LENGTH_SHORT).show();

                            Log.d("errorchk",t.getMessage());

                        }
                    });
        }

        else {
            Toast.makeText(getActivity(), getResources().getString(R.string.check_internet), Toast.LENGTH_SHORT).show();

        }

    }
}
