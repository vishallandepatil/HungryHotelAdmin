package com.hungry.hotel.hungryhoteladmin.restaurentmenu.listener;

public interface LoadMoreListener {

}
