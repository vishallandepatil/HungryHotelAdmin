package com.hungry.hotel.hungryhoteladmin.restaurentmenu.listener;

import com.hungry.hotel.hungryhoteladmin.restaurentmenu.model.Dish;

public interface EditMenuListener {
    void openEditMenu(Dish dish);
}
